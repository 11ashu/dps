    <!-- header -->
    <?php
    include_once('common/header.php');
    ?>
    <!-- menu -->
    <?php
    include_once('common/menu.php');
    ?>
    <!-- SLIDER -->
    <section id="resSlider">
        <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="item slider1 active">
                    <img src="img/slide2.jpg" alt="">
                    <div class="carousel-caption slider-con">
                        <h2>Welcome to <span>DPS</span></h2>
                        <p>We Provide that environment  where your child’s energy can grow in right direction</p>
                        <a href="#" class="bann-btn-2">Read More</a>
                    </div>
                </div>
                <!-- <div class="item">
                    <img src="img/slide2.jpg" alt="">
                    <div class="carousel-caption slider-con">
                        <h2>Admission open <span>2019</span></h2>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form</p>
                        <a href="#" class="bann-btn-2">Read More</a>
                    </div>
                </div> -->
                <div class="item">
                    <img src="img/slide3.jpg" alt="">
                    <div class="carousel-caption slider-con">
                        <h2>Build Your Child's<span> Future</span></h2>
                        <p>We Provide that environment  where your child’s energy can grow in right direction</p>
                        <a href="#" class="bann-btn-2">Read More</a>
                    </div>
                </div>
            </div>

            <!-- Left and right controls -->
            <a class="left carousel-control" href="#myCarousel" data-slide="prev" id="prev">
                <i class="fa fa-chevron-left slider-arr"></i>
            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next" id="next">
                <i class="fa fa-chevron-right slider-arr"></i>
            </a>
        </div>
    </section>

    <!-- QUICK LINKS -->
    <section>
        <div class="container">
            <div class="row">
                <div class="wed-hom-ser">
                    <ul>
                        <li>
                            <a href="#" class="waves-effect waves-light btn-large wed-pop-ser-btn"><img src="images/icon/h-ic1.png" alt=""> Academy</a>
                        </li>
                        <li>
                            <a href="#admission" class="waves-effect waves-light btn-large wed-pop-ser-btn"><img src="images/icon/h-ic2.png" alt=""> Admission</a>
                        </li>
                        <li>
                            <a href="#Facilities" class="waves-effect waves-light btn-large wed-pop-ser-btn"><img src="images/icon/h-ic4.png" alt=""> Facility</a>
                        </li>
                        <li>
                            <a href="gallery-photo.html" class="waves-effect waves-light btn-large wed-pop-ser-btn"><img src="images/icon/h-ic3.png" alt=""> Gallery</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- DISCOVER MORE -->
    <section class="pop-cour">
            <div class="container com-sp pad-bot-70">
                <div class="row">
                    <div class="con-title">
                        <h2>Welcome To <span> Dhananjay Public School</span></h2>
                        <p>Affiliated To CBSE Board New Delhi</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div>
                            <!--POPULAR COURSES-->
                            <div class="home-top-cour">
                                <!--POPULAR COURSES IMAGE-->
                                <div class="col-md-3"> <img src="img/home_03.jpg" alt="" class="img-responsive"> </div>
                                <!--POPULAR COURSES: CONTENT-->
                                <div class="col-md-9 home-top-cour-desc">
                                    <a href="#">
                                        <h3>Active Learning</h3>
                                    </a>
                                    <!-- <h4>Technology / Space / Aerospace</h4> -->
                                    <p>Active Learning is, in short, anything that students do in a classroom other than merely passively listening to an instructor's lecture...</p> 
                                    <div class="hom-list-share">
                                        <!-- <ul>
                                            <li><a href="course-details.html"><i class="fa fa-bar-chart" aria-hidden="true"></i> Book Now</a> </li>
                                            <li><a href="course-details.html"><i class="fa fa-eye" aria-hidden="true"></i>10 Aavailable</a> </li>
                                            <li><a href="course-details.html"><i class="fa fa-share-alt" aria-hidden="true"></i> 570</a> </li>
                                        </ul> -->
                                    </div>
                                </div>
                            </div>
                            <!--POPULAR COURSES-->
                            <div class="home-top-cour">
                                <!--POPULAR COURSES IMAGE-->
                                <div class="col-md-3"> <img src="img/home_05.jpg" alt=""> </div>
                                <!--POPULAR COURSES: CONTENT-->
                                <div class="col-md-9 home-top-cour-desc">
                                    <a href="#">
                                        <h3>Music Class</h3>
                                    </a>
                                    <!-- <h4>Technology / Space / Aerospace</h4> -->
                                    <p>Learn Indian Music Online with Blue Bells Public School! Enroll now for comprehensive lessonsin Carnatic and Hindustani music...</p> 
                                    <div class="hom-list-share">
                                        <!-- <ul>
                                            <li><a href="course-details.html"><i class="fa fa-bar-chart" aria-hidden="true"></i> Book Now</a> </li>
                                            <li><a href="course-details.html"><i class="fa fa-eye" aria-hidden="true"></i>40 Aavailable</a> </li>
                                            <li><a href="course-details.html"><i class="fa fa-share-alt" aria-hidden="true"></i> 320</a> </li>
                                        </ul> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div>
                            <!--POPULAR COURSES-->
                            <div class="home-top-cour">
                                <!--POPULAR COURSES IMAGE-->
                                <div class="col-md-3"> <img src="img/home_07.jpg" alt=""> </div>
                                <!--POPULAR COURSES: CONTENT-->
                                <div class="col-md-9 home-top-cour-desc">
                                    <a href="#">
                                        <h3>Yoga Class</h3>
                                    </a>
                                    <!-- <h4>Technology / Trends / Fashion</h4> -->
                                    <p>Put simply, Yoga/ Power Yoga is a series of postures designed to improve strength, balance and flexibility.  DPS offers classes for Yoga/ Power Yoga...</p> 
                                    <div class="hom-list-share">
                                        <!-- <ul>
                                            <li><a href="course-details.html"><i class="fa fa-bar-chart" aria-hidden="true"></i> Book Now</a> </li>
                                            <li><a href="course-details.html"><i class="fa fa-eye" aria-hidden="true"></i>10 Aavailable</a> </li>
                                            <li><a href="course-details.html"><i class="fa fa-share-alt" aria-hidden="true"></i> 570</a> </li>
                                        </ul> -->
                                    </div>
                                </div>
                            </div>
                            <!--POPULAR COURSES-->
                            <div class="home-top-cour">
                                <!--POPULAR COURSES IMAGE-->
                                <div class="col-md-3"> <img src="img/home_09.jpg" alt=""> </div>
                                <!--POPULAR COURSES: CONTENT-->
                                <div class="col-md-9 home-top-cour-desc">
                                    <a href="#">
                                        <h3>Martial Art Class</h3>
                                    </a>
                                    <!-- <h4>Technology / Space / Aerospace</h4> -->
                                    <p>Learn Martial Arts, Karate, Mixed Martial Arts, MMA, Kickboxing, Taekwondo, Self Defense & fitnessclasses, Training Centers, For Kids...</p> 
                                    <div class="hom-list-share">
                                        <!-- <ul>
                                            <li><a href="course-details.html"><i class="fa fa-bar-chart" aria-hidden="true"></i> Book Now</a> </li>
                                            <li><a href="course-details.html"><i class="fa fa-eye" aria-hidden="true"></i>40 Aavailable</a> </li>
                                            <li><a href="course-details.html"><i class="fa fa-share-alt" aria-hidden="true"></i> 320</a> </li>
                                        </ul> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
        
    <section>
            <div class="head-2">
                <!-- <div class="container"> -->
                        <div class="container  pad-bot-0">
                                <div class="row">
                                        <!-- <div class="row"> -->
                                    <div class="head-2-inn head-2-inn-padd-top">
                                        <h2 style="color:#fff;">Our Methodology</h2><br>
                                        <!-- <p>Fusce id sem at ligula laoreet hendrerit venenatis sed purus. Ut pellentesque maximus lacus, nec pharetra augue.</p> -->
                                    </div>
                                            <!-- </div> -->
                                    <div class="col-md-12">
                                        <!--<div class="ho-ex-title">
                                                <h4>Upcoming Event</h4>
                                            </div>-->
                                            <p style="color:#fff;" class="text-justify">
                                                    DPS’s core belief is that every child is unique and has an infinite potential, 
                                                    she/he just needs help in realizing it. Through Interactive iLLUME,  DPS helps 
                                                    children discover their learning style and inculcates the love for learning in 
                                                    their early years. Interactive iLLUME places a child at the center and all the 
                                                    eight pillars of Interactive iLLUME are designed around a child for his/her overall 
                                                    development. At DPS, parents are viewed as contributive and active partners Regular 
                                                    seminars and workshops are held to align parents with  DPS's approach and enable them 
                                                    to develop a safe, healthy, hygienic and developmentally appropriate environment even at
                                                        home A wide range of activities and programs are planned on a regular basis to provide 
                                                        children with experiences where they can explore their uniqueness and also supplement their 
                                                        classroom learning. Festival celebrations and outdoor visits are important learning tools at
                                                        DPS Public School.
                                            </p>
                                        <!-- <div class="ho-event ho-event-mob-bot-sp">
                                            
                                        </div> -->
                                    </div>
                                </div>
                        </div>
                <!-- </div> -->
            </div>
    </section>
       
    <section >
            <div class="container com-sp pad-bot-0" id="Facilities">
                    <div class="row">
                        <div class="con-title">
                            <h2>Our <span>Facilities</span></h2>
                            <!-- <p>Fusce id sem at ligula laoreet hendrerit venenatis sed purus. Ut pellentesque maximus lacus, nec pharetra augue.</p> -->
                        </div>
                    </div>
                    <!-- <div class="row">
                            
                    </div> -->
            </div>
            <div class="container pad-bot-0">
                <div class="row">
                    <div class="col-md-4">
                        <!--<div class="ho-ex-title">
                                <h4>Upcoming Event</h4>
                            </div>-->
                        <div class="ho-ev-latest ho-ev-latest-bg">
                            <div class="ho-lat-ev">
                                <h4>Libraries</h4>
                                <p>The school boasts of two well-stocked libraries with an impressive index of titles, periodicals, magazines, and newspapers</p>
                            </div>
                        </div>
                        <div class="ho-event ho-event-mob-bot-sp">
                                           
                        </div>
                    </div>
                    <div class="col-md-4">
                        <!--<div class="ho-ex-title">
                                <h4>Upcoming Event</h4>
                            </div>-->
                        <div class="ho-ev-latest ho-ev-latest-bg">
                            <div class="ho-lat-ev">
                                <h4>Interactive Screens in classrooms</h4>
                                <p>We have digital classrooms to teaching and digital learning.</p>
                            </div>
                        </div>
                        <div class="ho-event ho-event-mob-bot-sp">
                            
                        </div>
                    </div>
                    <div class="col-md-4">
                        <!--<div class="ho-ex-title">
                                <h4>Upcoming Event</h4>
                            </div>-->
                        <div class="ho-ev-latest ho-ev-latest-bg">
                            <div class="ho-lat-ev">
                                <h4>Science Laboratories</h4>
                                <p>To provide hands-on practical experience to our students, excellent equipment and facilities</p>
                            </div>
                        </div>
                    </div>
                    
                </div>
                <div class="row">
                        <div class="col-md-4">
                            <!--<div class="ho-ex-title">
                                    <h4>Upcoming Event</h4>
                                </div>-->
                            <div class="ho-ev-latest ho-ev-latest-bg">
                                <div class="ho-lat-ev">
                                    <h4>Art Room</h4>
                                    <p>The School is equipped with an Art Room where the creative surge of the student finds expression in varying forms. </p>
                                </div>
                            </div>
                            <div class="ho-event ho-event-mob-bot-sp">
                                               
                            </div>
                        </div>
                        <div class="col-md-4">
                            <!--<div class="ho-ex-title">
                                    <h4>Upcoming Event</h4>
                                </div>-->
                            <div class="ho-ev-latest ho-ev-latest-bg">
                                <div class="ho-lat-ev">
                                    <h4>Sports Facilities</h4>
                                    <p>Indoor Games Area, Synthetic courts for Badminton, Basketball, Volleyball & Throw ball.</p>
                                </div>
                            </div>
                            <div class="ho-event ho-event-mob-bot-sp">
                                
                            </div>
                        </div>
                        <div class="col-md-4">
                            <!--<div class="ho-ex-title">
                                    <h4>Upcoming Event</h4>
                                </div>-->
                            <div class="ho-ev-latest ho-ev-latest-bg">
                                <div class="ho-lat-ev">
                                    <h4>Auditorium</h4>
                                    <p>The multi-purpose auditorium provides an ideal space for school events, stage productions, and Inter-School activities.</p>
                                </div>
                            </div>
                        </div>
                        
                </div>
            </div>
    </section>
    <!-- footer -->
    <?php
        include_once('common/footer.php');
    ?>