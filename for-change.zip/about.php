    <!-- header -->
    <?php
    include_once('common/header.php');
    ?>
    <!-- menu -->
    <?php
    include_once('common/menu.php');
    ?>
    <!--END HEADER SECTION-->
    <section>
            <div class="head-2">
                <div class="container">
                    <div class="head-2-inn head-2-inn-padd-top">
                        <h1 style="color:#fff;">About Dhananjay Public School</h1>
                       
                    </div>
                </div>
            </div>
        </section>
    <!--SECTION START-->
    <section>
        <div class="container com-sp pad-bot-70">
            <div class="row">
                <div class="cor about-sp">
                    <div class="ed-about-tit">
                        <!-- <div class="con-title">
                            <h2>About <span> Academy</span></h2>
                            <p>Fusce id sem at ligula laoreet hendrerit venenatis sed purus. Ut pellentesque maximus lacus, nec pharetra augue.</p>
                        </div> -->
                        <blockquote class="blockquote text-right">
  <p class="mb-0">Knowledge is the only wealth of human being which no one can take.The root cause of poverty is uneducation. This institution that is Dhananjay Public School has fully taken the liabilty to impart education on a very reasonable expense to all the children irrespective of thier cast, colour, religion etc.</p>
  <footer class="blockquote-footer"><b>Mr. Prabhakar Tiwari </b><cite title="Source Title">Managing Director</cite></footer>
</blockquote>
                    </div>
                    <div class="ed-about-sec1">
                        <div class="ed-advan">
                            <ul>
                                <!-- <li>
                                    <div class="ed-ad-img">
                                        <img src="images/adv/1.png" alt="">
                                    </div>
                                    <div class="ed-ad-dec">
                                        <h4>Awards</h4>
                                        <p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Morbi bibendum imperdiet bibendum.</p>
                                        
                                    </div>
                                </li> -->
                                <li>
                                    <div class="ed-ad-img">
                                        <img src="images/adv/2.png" alt="">
                                    </div>
                                    <div class="ed-ad-dec">
                                        <h4>Vision</h4>
                                        <p>Our Vision is to Development of students as principled Leaders - understanding values and international mindedness</p>
                                        
                                    </div>
                                </li>
                                <li>
                                    <div class="ed-ad-img">
                                        <img src="images/adv/3.png" alt="">
                                    </div>
                                    <div class="ed-ad-dec">
                                        <h4>Educations</h4>
                                        <p>A school is an educational institution designed to provide learning spaces and learning environments for the teaching of students.</p>
                                       
                                    </div>
                                </li>
                                <!-- <li>
                                    <div class="ed-ad-img">
                                        <img src="images/adv/4.png" alt="">
                                    </div>
                                    <div class="ed-ad-dec">
                                        <h4>Alumni</h4>
                                        <p>Aliquam malesuada commodo lectus, at fermentum ligula finibus eu. Morbi nisi neque, suscipit non pulvinar vitae.</p>
                                        
                                    </div>
                                </li> -->
                                <li>
                                    <div class="ed-ad-img">
                                        <img src="images/adv/5.png" alt="">
                                    </div>
                                    <div class="ed-ad-dec">
                                        <h4>Facilities</h4>
                                        <p> We foster growth and achievement by enabling our students to get the support they need to reach the goals they set for themselves.</p>
                                       
                                    </div>
                                </li>
                                <!-- <li>
                                    <div class="ed-ad-img">
                                        <img src="images/adv/6.png" alt="">
                                    </div>
                                    <div class="ed-ad-dec">
                                        <h4>Departments</h4>
                                        <p>Maecenas venenatis, turpis ac tincidunt convallis, leo enim ultrices tortor, at faucibus neque sapien ac elit. Curabitur ut ipsum odio.</p>
                                       
                                    </div>
                                </li> -->
                            </ul>
                        </div>
                    </div>
                    <div class="ed-about-sec1">
                        <div class="col-md-6"></div>
                        <div class="col-md-6"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--SECTION END-->
    <!-- footer -->
    <?php
        include_once('common/footer.php');
    ?>