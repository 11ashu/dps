    <!-- header -->
    <?php
    include_once('common/header.php');
    ?>
    <!-- menu -->
    <?php
    include_once('common/menu.php');
    ?>
   <section>
        <div class="head-2">
            <div class="container">
                <div class="head-2-inn head-2-inn-padd-top">
                    <h1>Photo Gallery</h1>
                </div>
            </div>
        </div>
    </section>	
	
    <!--SECTION START-->
    <section>
        <div class="ed-res-bg">
		<div class="container com-sp pad-bot-70 ed-res-bg">
            <div class="row">
                <div class="cor about-sp h-gal ed-pho-gal">
					<ul>
						<li><img class="materialboxed" data-caption="DPS" src="img/IMG-20190808-WA0052.jpg" alt="">
						</li>
						<li><img class="materialboxed" data-caption="DPS" src="img/IMG-20190808-WA0051.jpg" alt="">
						</li>
						<li><img class="materialboxed" data-caption="DPS" src="img/IMG-20190808-WA0027.jpg" alt="">
						</li>
						<li><img class="materialboxed" data-caption="DPS" src="img/IMG-20190808-WA0029.jpg" alt="">
						</li>
						<li><img class="materialboxed" data-caption="DPS" src="img/IMG-20190808-WA0035.jpg" alt="">
						</li>
						<li><img class="materialboxed" data-caption="DPS" src="img/IMG-20190808-WA0045.jpg" alt="">
						</li>
						<li><img class="materialboxed" data-caption="DPS" src="img/IMG-20190808-WA0046.jpg" alt="">
						</li>
						<li><img class="materialboxed" data-caption="DPS" src="img/IMG-20190808-WA0047.jpg" alt="">
						</li>
						<li><img class="materialboxed" data-caption="DPS" src="img/IMG-20190808-WA0048.jpg" alt="">
						</li>
						<!-- <li><img class="materialboxed" data-caption="DPS" src="images/ami/6.jpg" alt="">
						</li>
						<li><img class="materialboxed" data-caption="DPS" src="images/ami/7.jpg" alt="">
						</li>
						<li><img class="materialboxed" data-caption="DPS" src="images/ami/8.jpg" alt="">
						</li> -->
					</ul>
                </div>
            </div>
        </div>
		</div>
    </section>
    <!--SECTION END-->


    <!-- footer -->
    <?php
        include_once('common/footer.php');
    ?>