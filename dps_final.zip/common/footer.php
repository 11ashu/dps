    <section id="admission">
            <div class="full-bot-book com-sp pad-bot-70" style="margin-top: 60px;">
                <div class="container ">
                    <div class="row">
                        <div class="bot-book">
                            <div class="col-md-2 bb-img">
                                <img src="images/3.png" alt="">
                            </div>
                            <div class="col-md-7 bb-text">
                                <h3 style="color: #fff;">Voice Your Dream With Dhananjay Public School...</h3>
                                
                            </div>
                            <div class="col-md-3 bb-link">
                                <a href="course-details.html">Admission</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    </section>
    <!-- FOOTER -->
    
    <section class="wed-hom-footer">
        <div class="container">
            <div class="row wed-foot-link">
                <div class="col-md-4 foot-tc-mar-t-o">
                    <h4>About Dhananjay Public School</h4>
                    <p>The school strives to provide a stimulating environment so that each child’s energy is channelized in the right direction.</p>
                </div>
                <div class="col-md-4">
                    <h4>Get in Touch</h4>
                    <p>Address:  Azamgarh Faizabad Highway, Atraulia P.O, Jagdishpur, Uttar Pradesh 223223</p>
                    <p>Phone: <a href="#!">095985 19463</a></p>
                    <!-- <p>Email: <a href="#!">info@edu.com</a></p> -->
                </div>
                <div class="col-md-4">
                    <h4>HELP & SUPPORT</h4>
                    <ul>
                        <li><a href="#">24x7 Live help</a>
                        </li>
                        <li><a href="contact">Contact us</a>
                        </li>
                        <li><a href="#">Feedback</a>
                        </li>
                        <li><a href="#">FAQs</a>
                        </li>
                    </ul>
                   
                </div>
            </div>
            <div class="row wed-foot-link-1">
                <div class="col-md-4">
                </div>
                <div class="col-md-4">
                    <h4 class="text-center">SOCIAL MEDIA</h4>
                    <ul style="position: relative;left:80px;top:-10px;">
                        <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a>
                        </li>
                        <li><a href="#"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>
                        </li>
                    </ul>
                    <p class="text-center">Copyright &copy; <?php echo date('Y')?> DPS Atraulia, Azamgarh</p>
                </div>
                <div class="col-md-4">
                </div>
            </div>
        </div>
    </section>

    <!-- SOCIAL MEDIA SHARE -->
    <section>
        <div class="icon-float" id="share">
            <ul>
                <li><a href="#" class="sh">1k <br> Share</a> </li>
                <li><a href="#" class="fb1"><i class="fa fa-facebook" aria-hidden="true"></i></a> </li>
                <li><a href="#" class="gp1"><i class="fa fa-google-plus" aria-hidden="true"></i></a> </li>
                <li><a href="#" class="tw1"><i class="fa fa-twitter" aria-hidden="true"></i></a> </li>
                <li><a href="#" class="li1"><i class="fa fa-linkedin" aria-hidden="true"></i></a> </li>
                <li><a href="#" class="wa1"><i class="fa fa-whatsapp" aria-hidden="true"></i></a> </li>
                <li><a href="#" class="sh1"><i class="fa fa-envelope-o" aria-hidden="true"></i></a> </li>
            </ul>
        </div>
    </section>

    <!--Import jQuery before materialize.js-->
    <script src="js/main.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/materialize.min.js"></script>
    <script src="js/custom.js"></script>
</body>

</html>